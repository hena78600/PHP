<?php
include('header.php');
if(isset($_SESSION['users'])) {
	$email = $_SESSION['users'];
	$chk = mysqli_query($con, "SELECT * FROM users WHERE email = '$email'");
	$fetch = mysqli_fetch_assoc($chk);
}
if(isset($_GET['id'])){
	$id = base64_decode($_GET['id']);
	$sql = mysqli_query($con, "SELECT * FROM flight_details WHERE fid='$id'");
	$row = mysqli_fetch_assoc($sql);
}
?>
<section class="sec-booking">
<div class="main">
			<!-- MAIN CONTENT -->
			<form action="" method="POST">
			<div class="main-content" style="padding-top: 20px;">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							<h2>Traveller Details</h2>
							<div class="panel">
								<div class="panel-heading">
								</div>
								
								<div class="panel-body">
									<div class="col-sm-2"><label>Contact Details</label></div><div class="col-sm-4"><input type="text" name="mnumber" id="mnumber" placeholder="Contact Number" value="<?php echo $fetch['phone']; ?>" class="form-control"></div>
								</div>
							</div>
						</div>
						<div class="col-md-3" style="padding-top: 62px;">
							<div class="panel">
								<div class="panel-heading">
									<p>Base Fare <span class="pull-right">&#x20b9; <?php echo $row['f_fare']; ?></span></p>
									<input type="hidden" name="amount" value="<?php echo $row['f_fare']; ?>">
								</div>
								
								<div class="panel-body">
									<div class="col-md-6">
										<p style="padding-top: 15px;">No. of seats</p>
									</div>
									<div class="col-md-6">
									 <div class="input-group">
	                                    <span class="input-group-btn">
	                                        <button type="button" class="quantity-left-minus btn-sm btn-danger btn-number"  data-type="minus" data-field="">
	                                          <span class="glyphicon glyphicon-minus"></span>
	                                        </button>
	                                    </span>
	                                    <input type="text" id="quantity" name="seats" class="form-control input-number" value="1" min="1" max="20">
	                                    <span class="input-group-btn">
	                                        <button type="button" class="quantity-right-plus btn-sm btn-success btn-number" data-type="plus" data-field="">
	                                            <span class="glyphicon glyphicon-plus"></span>
	                                        </button>
	                                    </span>
	                                </div>
	                            </div>
								</div>
							</div>
						</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		 <div class="main-content" style="padding-top: 20px;">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							<div class="panel">
								<div class="panel-heading">
									<p>Traveller Information</p>
								</div>
								<div class="panel-body">
									<div class="col-sm-2"><label>Adult1</label></div><div class="col-sm-4"><input type="text" name="tname" id="tname" placeholder="Traveller Name" class="form-control" required></div><div class="col-sm-4"><input type="date" name="tdate" id="tdate" placeholder="Traveller Name" class="form-control" required></div>
								</div>
							</div>
						</div>
				</div>
			</div>
		</div> 
		<div class="main-content" style="padding-top: 20px;">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							
							<div class="panel">
								<div class="panel-heading">
									
								</div>
								
								<div class="panel-body">
									<div class="col-sm-2"><button type="submit" name="submit" class="btn btn-danger">Proceed to Payment</button></div>
								</div>
							</div>
						</div>
				</div>
			</div>
		</div>
		</form> 
		<?php
		if(isset($_POST['submit'])){
			$mnumber = $_POST['mnumber'];
			$amount = $_POST['amount'];
			$seats = $_POST['seats'];
			$total_amt = $amount*$seats;
			$tname = $_POST['tname'];
			$tdate = $_POST['tdate'];
			mysqli_query($con, "UPDATE users SET phone = '$mnumber' WHERE email = '$email'");
			//echo $seats; exit;
			$sql = mysqli_query($con, "INSERT INTO booking (t_name, t_time, contact, payable_amt, seats) VALUES('$tname', '$tdate', '$mnumber', '$total_amt', '$seats')");
			echo "Booking Done";
		}

		?>
	</div>
</section>







<script>
var room = 1;
function education_fields() {
 
    room++;
    var objTo = document.getElementById('education_fields')
    var divtest = document.createElement("div");
	divtest.setAttribute("class", "form-group removeclass"+room);
	var rdiv = 'removeclass'+room;
    divtest.innerHTML = '<div class="col-sm-3 nopadding"><div class="form-group"> <input type="text" class="form-control" id="Schoolname" name="Schoolname[]" value="" placeholder="School name"></div></div><div class="col-sm-3 nopadding"><div class="form-group"> <input type="text" class="form-control" id="Major" name="Major[]" value="" placeholder="Major"></div></div><div class="col-sm-3 nopadding"><div class="form-group"> <input type="text" class="form-control" id="Degree" name="Degree[]" value="" placeholder="Degree"></div></div><div class="col-sm-3 nopadding"><div class="form-group"><div class="input-group"> <select class="form-control" id="educationDate" name="educationDate[]"><option value="">Date</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option> </select><div class="input-group-btn"> <button class="btn btn-danger" type="button" onclick="remove_education_fields('+ room +');"> <span class="glyphicon glyphicon-minus" aria-hidden="true"></span> </button></div></div></div></div><div class="clear"></div>';
    
    objTo.appendChild(divtest)
}
   function remove_education_fields(rid) {
	   $('.removeclass'+rid).remove();
   }
</script>
<script>
	$(document).ready(function(){

var quantitiy=0;
   $('.quantity-right-plus').click(function(e){
        
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        var quantity = parseInt($('#quantity').val());
        
        // If is not undefined
            
            $('#quantity').val(quantity + 1);

          
            // Increment
        
    });

     $('.quantity-left-minus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        var quantity = parseInt($('#quantity').val());
        
        // If is not undefined
      
            // Increment
            if(quantity>1){
            $('#quantity').val(quantity - 1);
            }
    });
    
});
	</script>.
<?php include('footer.php');
?>