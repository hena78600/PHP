<?php
include('../function.php');
if(isset($_POST['name']))
$name = $_POST['name'];
$Numseats = $_POST['Numseats'];
$seats = $_POST['seats'];
echo $seats;


?>