<?php
include_once("function.php");
if(isset($_SESSION['users'])){
    $email = $_SESSION['users'];
}
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $dept = $_GET['dept'];
    $arival = $_GET['arival'];
    $deptdate = $_GET['deptdate'];
    $arivaldate = $_GET['arivaldate'];

    $sql = mysqli_query($con, "SELECT * FROM seats WHERE flight_id = '$id' AND user_email = '$email'");
    //$row = mysqli_fetch_array($sql);
}
require('libs/fpdf.php');
class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('logo.png',10,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'Title',1,0,'C');
    // Line break
    $this->Ln(20);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf = new FPDF('p', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(60,10,'Ticket - Confirmed',0,1,'C');
$pdf->SetFont('Arial','',14);
$pdf->Cell(60,10,'Date: ',0,0,'');
$pdf->Cell(60,10,'Date: ',0,0,'');
$pdf->Output();
?>
