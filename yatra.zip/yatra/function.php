<?php
SESSION_start();
$con = mysqli_connect("localhost", "root", "123", "yatra");
?>