<?php
include('header.php'); 
if(isset($_GET['dep'])){

	$sql= "SELECT * FROM flight_details WHERE ";
	if(!empty($_GET['dep'])){
		$dep = $_GET['dep'];
		$sql.= " routes_from LIKE '%$dep%'";
	if(!empty($_GET['arival'])){
		$arival = $_GET['arival'];
		$sql.= "AND routes_to LIKE '%$arival%'";
	}
	}if(!empty($_GET['from-date1']) || !empty($_GET['to-date'])){
		$from_date = strtotime($_GET['from-date1']);
		$to_date = strtotime($_GET['to-date']);
		$dates = (!empty($from_date)) ? $from_date : $to_date;
	    $day = date('l', $dates);
		$sql.= " AND f_available LIKE '%$day%'";
	}if(!empty($_GET['nooftraveller'])){
		$nooftraveller = $_GET['nooftraveller'];
		$sql.= " AND seats >= $nooftraveller";
	}if($_GET['dep'] == $_GET['arival']){
		echo "<script>alert('Arival Time should be different from depart time');</script>";
		echo "<script>window.location.href='index.php'; </script>";
	}
	//echo $sql;
	$sql = mysqli_query($con, $sql);
?>
<section class="sec-booking">
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content" style="padding-top: 50px;">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-8">
							<!-- BASIC TABLE -->
							<?php while($row = mysqli_fetch_assoc($sql)){
								?>
							<div class="panel">
								<div class="panel-heading">
								</div>
								<div class="panel-body">
									<?php /*$time1 = strtotime($row['start_time']);
									$time2 = strtotime($row['destination_time']);
									$difference = $time1-$time2;
									$tym = floor($difference/(60));*/
									$datetime1 = new DateTime($row['start_time']);
									$datetime2 = new DateTime($row['destination_time']);
									$interval = $datetime1->diff($datetime2);

									?>
									<?php echo $row['routes_from']; ?> to <?php echo $row['routes_to']; ?>
									<p><?php echo $row['start_time']; ?> &nbsp;&nbsp; <?php echo $row['destination_time']; ?><span class="cal_time"><?php echo $interval->format('%h')." Hours ".$interval->format('%i')." Minutes"; ?></span>
									<span class="text-info pull-right">&#x20b9; <?php echo $row['f_fare']; ?>&nbsp;&nbsp; <?php if(isset($_SESSION['users'])) { ?><a href="booking.php?id=<?php echo base64_encode($row['fid']) ?> &amp;nooftraveller=<?php echo $_GET['nooftraveller']; ?> &amp;deptdate=<?php echo $_GET['from-date1']; ?> &amp;arivaldate=<?php echo $_GET['to-date']; ?> &amp;deptdate=<?php echo $_GET['from-date1']; ?> &amp;dept=<?php echo $_GET['dep']; ?> &amp;arival=<?php echo $_GET['arival']; ?>" class="btn btn-warning">BOOK NOW</a><?php } else{ ?> <a href="login.php" class="btn btn-warning">BOOK NOW</a><?php } ?>
									</span></p>
								</div>
							</div>
							<?php } ?>
							<!-- END BASIC TABLE -->
						</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
	</div>
</section>
<?php } ?>



<?php include('footer.php');
?>