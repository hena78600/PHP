<?php include('header.php'); 
include ('sidebar.php');
include('function.php');

?>
<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Flight Details</h3>
					<div class="row">
						<div class="col-md-8">
							<!-- BASIC TABLE -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">List Of Flights</h3>
								</div>
								<div class="panel-body">
									<table class="table">
										<thead>
											<tr>
												<th>Flight Id</th>
												<th>Routes From</th>
												<th>Routes To</th>
												<th>Strat Time</th>
												<th>Destination Time</th>
												<th>Week Days Availability</th>
												<th>Available Seats</th>
												<th>Flight Fare</th>
											</tr>
										</thead>
										<tbody>
											<?php $sql = mysqli_query($con, "SELECT * FROM flight_details") ;
											while($row = mysqli_fetch_assoc($sql)){
											?>
											<tr>
												<td><?php echo $row['fid'] ?></td>
												<td><?php echo $row['routes_from'] ?></td>
												<td><?php echo $row['routes_to'] ?></td>
												<td><?php echo $row['start_time'] ?></td>
												<td><?php echo $row['destination_time'] ?></td>
												<td><?php echo $row['f_available']; ?></td>
												<td><?php echo $row['seats'] ?></td>
												<td><?php echo $row['f_fare'] ?></td>
											</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>
							<!-- END BASIC TABLE -->
						</div>
						
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
	</div>
		
	<?php include('footer.php'); ?>