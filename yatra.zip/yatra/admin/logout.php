<?php
SESSION_destroy();
header('location:index.php');
?>