<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="#" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="booking_details.php" class=""><i class="lnr lnr-cog"></i> <span>Booking Details</span></a></li>
						
						<li>
							<a href="#flightmngmt" data-toggle="collapse" class="collapsed"><i class="lnr lnr-file-empty"></i> <span>Flights Management</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="flightmngmt" class="collapse ">
								<ul class="nav">
									<li><a href="flight_details.php" class="">Add Flight Details</a></li>
									<li><a href="routes.php" class="">Domestic Routes in India</a></li>
									
								</ul>
							</div>
						</li>
						<li><a href="flight_list.php" class=""><i class="lnr lnr-dice"></i> <span>List Of Flights</span></a></li>
						<li>
							<a href="#subPages" data-toggle="collapse" class="collapsed"><i class="lnr lnr-file-empty"></i> <span>My Profile</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="subPages" class="collapse ">
								<ul class="nav">
									<li><a href="profile.php" class="">Profile</a></li>
									<li><a href="logout.php" class="">Logout</a></li>
								</ul>
							</div>
						</li>
						
						
					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->