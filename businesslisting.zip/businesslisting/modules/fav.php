<?php 
include('../function.php');
if(isset($_POST['b_id'])){
	$id = $_POST['b_id'];
	$email = $_SESSION['users'];
	$res = mysqli_query($con, "SELECT * FROM user_fav WHERE bus_id = '$id' AND user_email = '$email'");
	if(mysqli_num_rows($res) == 0){
		$insert = mysqli_query($con, "INSERT INTO user_fav (bus_id, user_email) VALUES('$id', '$email') ");
		echo "seccess";
		
	}else{			
		$del = mysqli_query($con, "DELETE FROM user_fav WHERE bus_id = '$id' AND user_email = '$email'");
		echo "success";
	}
}


?>