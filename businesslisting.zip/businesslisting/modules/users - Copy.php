<?php
/*echo '<pre>';
print_r($_POST);
print_r($_FILES);
die;*/
require '../function.php';
if(isset($_POST['user_name'], $_POST['bus_name'])){
	/*echo "<pre>";
	print_r($_FILES);
	echo"</pre>";
	echo "<pre>";
	print_r($_POST);
	echo"</pre>";*/
	$name = $_POST['user_name'];
	//echo $name; exit;
	$bus_name = $_POST['bus_name'];
	$bus_cat = $_POST['bus_cat'];
	$email = $_POST['email'];
	$Inputmobileno = $_POST['Inputmobileno'];
	//echo $Inputmobileno; exit;
	$pass = $_POST['Input_pass'];

	$inputAddress = $_POST['inputAddress'];

	$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["bus_logo"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$check = getimagesize($_FILES["bus_logo"]["tmp_name"]);
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
// Check file size
if ($_FILES["bus_logo"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}elseif(move_uploaded_file($_FILES['bus_logo']['tmp_name'], "$target_file")){
	



	$date_estab = $_POST['date_estab'];
	$news = $_POST['news'];
	$hear_abt = implode(',',$_POST['ch']);
	
	$descr = $_POST['desc'];

	$check = mysqli_query($con, "SELECT * FROM users WHERE email='$email'");
	if(mysqli_num_rows($check) > 0 ){
		echo "Email Id already registered";
	}else{
		mysqli_query($con, "INSERT INTO users(name, bus_name, bus_cat, email, mobile, password, address, logo, dateofestab, newsletter,howtohear, description, status) VALUES ('$name', '$bus_name', '$bus_cat', '$email', '$Inputmobileno', '$pass', '$inputAddress', '$bus_logo', '$date_estab', '$news','$hear_abt', '$descr', 'PENDING')");
        echo 'Registered successfully You can now Sign In';
    }
}
}
if(isset($_POST['inputemail'], $_POST['inputpass'])){
	$email = $_POST['inputemail'];
	$pass = $_POST['inputpass'];
	$RememberMe = $_POST['RememberMe'];
	$check = mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND password='$pass'");
	if(mysqli_num_rows($check) == 0){
		echo "Invalid Email or Password";
	}else if(isset($_POST["RememberMe"])){
		setcookie('email', $email, time()+60*60*7);
		setcookie('pass', $pass, time()+60*60*7);
		echo "cookie set";
		$row = mysqli_fetch_assoc($check);
		$email = $row['email'];
		$_SESSION['users'] = $email;
		//echo "Success";
		/*header("Location: ../profile.php");*/
		echo '<script> window.location.href = "profile.php";</script>';
		}
	}



/*File uplaod code*/

   
