<?php
include '../function.php';
$con = connect_db();
if(isset($_POST['email'])){
	$email = $_POST['email'];
	/*echo $email; exit;*/
	$check = mysqli_query($con, "SELECT * from users WHERE email='$email'");
	$count = mysqli_num_rows($check);
	if($count >0 ){
/*		echo "send email to the users";*/
	$row = mysqli_fetch_assoc($check);
	$email_id = $row['email'];
	$password = $row['password'];
	$to = $email_id;
                $subject = "Password";
                $txt = "Your password is : $password.";
                $headers = "From: password@businesslisting.com" . "\r\n" .
                "CC: businesslisting123@example.com";
                //echo $to,$subject,$txt,$headers;
                echo "Check your email to reset your password";
                /*mail($to,$subject,$txt,$headers);*/
	}else{
		echo "Email is not Registered";
	}

}





 ?>
