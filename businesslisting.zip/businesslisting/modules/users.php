<?php
/*echo '<pre>';
print_r($_POST);
print_r($_FILES);
die;*/
require '../function.php';
if(isset($_POST['user_name'], $_POST['bus_name'])){
	/*echo "<pre>";
	print_r($_FILES);
	echo"</pre>";
	echo "<pre>";
	print_r($_POST);
	echo"</pre>";*/
	$name = $_POST['user_name'];
	//echo $name; exit;
	$bus_name = $_POST['bus_name'];
	$bus_cat = $_POST['bus_cat'];
	$email = $_POST['email'];
	$Inputmobileno = $_POST['Inputmobileno'];
	//echo $Inputmobileno; exit;
	$pass = md5($_POST['Input_pass']);

	$inputAddress = $_POST['inputAddress'];
	$date = $_POST['date_estab'];
	$date_estab = date('Y-m-d',strtotime($date));
	$news = $_POST['subscribe'];
	//echo $news; exit;
	//$hear_abt = implode(',',$_POST['ch']);
	$checkbox1=$_POST['ch'];
	$ch="";
	foreach($checkbox1 as $chk1)
	{
	   $ch .= $chk1.",";
	   //echo $ch; exit;
 	}
 	
	//$hear_abt = $_POST['ch'];
	$descr = $_POST['desc'];

	$fileinfo = getimagesize($_FILES["bus_logo"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "png",
        "jpg",
        "jpeg"
    );
    
    // Get image file extension
    $file_extension = pathinfo($_FILES["bus_logo"]["name"], PATHINFO_EXTENSION);
    
    // Validate file input to check if is not empty
    if (! file_exists($_FILES["bus_logo"]["tmp_name"])) {
        echo 'Choose image file to upload.';
    }    // Validate file input to check if is with valid extension
    else if (! in_array($file_extension, $allowed_image_extension)) {
        echo 'Upload valid images. Only PNG and JPEG are allowed.';
    }    // Validate image file size
    else if (($_FILES["bus_logo"]["size"] > 2000000)) {
        echo 'Image size exceeds 2MB';
    }    // Validate image file dimension
    else if ($width > "200" || $height > "150") {
        echo 'Image dimension should be within 200X150';
    } else {
    	$target = "../uploads/" . basename($_FILES["bus_logo"]["name"]);
    	$bus_logo = basename($_FILES["bus_logo"]["name"]);
        if (move_uploaded_file($_FILES["bus_logo"]["tmp_name"], $target)) {
           
        	/*echo "<pre>";
        	print_r($_POST);
        	print_r($_FILES);
        	echo "</pre>";
        	die;*/
	/*$targetDir = "../uploads/";
	$fileName = basename($_FILES['bus_logo']['name']);
	$targetFilePath = $targetDir . $fileName;
	$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
	$allowType = array('jpg', 'png', 'jpeg','gif');
	if(in_array($fileType, $allowType)){
		if(move_uploaded_file($_FILES['bus_logo']['tmp_name'], $targetFilePath)){*/

	
	$check = mysqli_query($con, "SELECT * FROM users WHERE email='$email' ");
	if(mysqli_num_rows($check) > 0 ){
		echo "Email Id already registered";
	}else {
		$chk = mysqli_query($con, "SELECT * FROM users WHERE mobile='$Inputmobileno' ");
		if(mysqli_num_rows($chk) > 0){
			echo "Mobile Number already registered";
		}else{
			
			$user_password = rand(100000,999999);
		    $user_encrypted_password = password_hash($user_password, PASSWORD_DEFAULT);
		    $user_activation_code = md5(rand());
		if(mysqli_query($con, "INSERT INTO users(name, bus_name, bus_cat, email, mobile, password, address, logo, dateofestab, newsletter,howtohear, description, status, activation_code, email_status) VALUES ('$name', '$bus_name', '$bus_cat', '$email', '$Inputmobileno', '$pass', '$inputAddress', '$bus_logo', '$date_estab', '$news','$ch', '$descr', 'PENDING', '$user_activation_code', 'not verified')")){

			$base_url = "http://localhost/businesslisting/modules/";
		   	$mail_body = "
		   <p>Hi ".$_POST['user_name'].",</p>
		   <p>Thanks for Registration. Your password is ".$user_password.", This password will work only after your email verification.</p>
		   <p>Please Open this link to verified your email address - ".$base_url."email_verification.php?activation_code=".$user_activation_code."
		   <p>Best Regards,<br />Businesslisting</p>
		   ";
		   require 'class/class.phpmailer.php';
		   $mail = new PHPMailer;
		   $mail->IsSMTP();        //Sets Mailer to send message using SMTP
		   $mail->Host = 'smtpout.secureserver.net';  //Sets the SMTP hosts of your Email hosting, this for Godaddy
		   $mail->Port = '80';        //Sets the default SMTP server port
		   $mail->SMTPAuth = true;       //Sets SMTP authentication. Utilizes the Username and Password variables
		   $mail->Username = 'xxxxxxxx';     //Sets SMTP username
		   $mail->Password = 'xxxxxxxx';     //Sets SMTP password
		   $mail->SMTPSecure = '';       //Sets connection prefix. Options are "", "ssl" or "tls"
		   $mail->From = 'henaara07@gmail.com';   //Sets the From email address for the message
		   $mail->FromName = 'Businesslisting';     //Sets the From name of the message
		   $mail->AddAddress($_POST['email'], $_POST['user_name']);  //Adds a "To" address   
		   $mail->WordWrap = 50;       //Sets word wrapping on the body of the message to a given number of characters
		   $mail->IsHTML(true);       //Sets message type to HTML    
		   $mail->Subject = 'Email Verification';   //Sets the Subject of the message
		   $mail->Body = $mail_body;       //An HTML or plain text message body
		   if($mail->Send())        //Send an Email. Return true on success or false on error
		   {
		    $message = '<label class="text-success">Register Done, Please check your mail.</label>';
		   }
		   echo '--Registeration Done-- ,Please Open this link to verified your email address -  '.$base_url.'email_verification.php?activation_code='.$user_activation_code.'';
		   echo "<script>
			document.getElementsByName('user_name')[0].value='';
			document.getElementsByName('bus_name')[0].value='';
			document.getElementsByName('bus_cat')[0].value='';
			document.getElementsByName('email')[0].value='';
			document.getElementsByName('Inputmobileno')[0].value='';
			document.getElementsByName('Input_pass')[0].value='';
			document.getElementsByName('inputAddress')[0].value='';
			document.getElementsByName('date_estab')[0].value='';

			document.getElementsByName('subscribe')[0].length='';
			document.getElementsByName('ch').checked = false;
			document.getElementsByName('desc')[0].value='';
			document.getElementsByName('bus_logo')[0].value='';
			</script>";
		}       
    }
}
}
}
}


if(isset($_POST['inputemail'], $_POST['inputpass'])){
	$email = $_POST['inputemail'];
	$pass = md5($_POST['inputpass']);
	$RememberMe = $_POST['RememberMe'];
	//echo $RememberMe; exit;
	$check = mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND password='$pass'");
	if(mysqli_num_rows($check) == 0){
		echo "Invalid Email or Password";
	}else{
		$row = mysqli_fetch_assoc($check);
		if($row['email_status'] === 'verified' && $row['status'] === 'APPROVED'){
		$email = $row['email'];
		$_SESSION['users'] = $email;
		/*echo "Success";*/
		// /*header("Location: ../profile.php");*/
		if(!empty($_POST['RememberMe'] && $RememberMe == 1)){
				setcookie('email', $email, time()+ 86400*30,"/");
				setcookie('pass', $_POST['inputpass'], time()+ 86400*30,"/");
				setcookie('RememberMe', $_POST['RememberMe'], time()+ 86400*30,"/");
			}
		else{
			setcookie('email', '');
			setcookie('pass', '');
			setcookie('RememberMe', '');
		}
		echo '<script> window.location.href = "profile.php";</script>';
	} else{
	echo "Please First Verify, your email address";
}
}
		
		
	}




/*File uplaod code*/

   
