<?php include('header.php'); ?>
<?php include('sidebar.php');
$con = connect_db();
if(isset($_GET['user_id'])){
    $id = $_GET['user_id'];
    $sql = mysqli_query($con, "SELECT * FROM business_category WHERE id='$id'");
    $row = mysqli_fetch_assoc($sql);
    
?>
<section class="sec-profile-admn">
<div class="container">
    <div class="row">
        <div class="col-lg-6 col-xlg-9 col-md-7 col-md-offset-2">
                        <div class="card">
                            <div class="card-block">
                                
                                    <form id="edit_cat.php" method="POST">
                                        <div class="form-group" style="display: none;">
                                            <input type="text" name="inputid" value="<?php echo $row['id']; ?>" class="form-control form-control-line">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12">Edit Category</label>
                                            <div class="col-md-12">
                                                <input type="text" name="inputName" placeholder="Category Name" value="<?php echo $row['cat_name']; ?>" class="form-control form-control-line">
                                            </div>
                                        </div>
                                    
                                        <div class="form-group">
                                            <div class="col-sm-12">                                            
                                                <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Add">
                                            </div>
                                        </div>
                                    </form>
                                    </div>
                                  </div>

                            </div>
                        </div>
                    </div>

</section>

<?php } ?>
<?php
if(isset($_POST['submit']))
{
    $id = $_POST['inputid'];
    $name = $_POST['inputName'];
    $sql = mysqli_query($con, "UPDATE business_category SET cat_name='$name' WHERE id = '$id'");
    echo "<script>alert('Category Updated Successfully');</script>";
        echo "<script>window.location.href='business_cat.php'</script>";
}


?>


<?php include('footer.php'); ?>