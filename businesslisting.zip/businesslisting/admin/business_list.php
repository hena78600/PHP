<?php
include('header.php');
include('sidebar.php'); 
$con = connect_db(); 
if(!isset($_SESSION['admin'])){
    header('location:index.php');
}
    //$sql = mysqli_query($con, "SELECT * FROM users");
 if(isset($_POST['submit'])){
    $valueToSearch = $_POST['valueToSearch'];
    //echo $valueToSearch; exit;
    
    $query = "SELECT * FROM users WHERE name LIKE '%$valueToSearch%' OR bus_name LIKE '%$valueToSearch%' OR bus_cat LIKE '%$valueToSearch%' OR email LIKE '%$valueToSearch%' OR mobile LIKE '%$valueToSearch%' OR description LIKE '%$valueToSearch%' ORDER BY id DESC";
    $search_result = filterTable($query);
  }else{
    $query = "SELECT * FROM users";
    $search_result = filterTable($query);
  }
  function filterTable($query){
    $con = connect_db();
    $filter_result = mysqli_query($con, $query);
    return $filter_result;
  }
?>
<section class="sec-profile-admn">
<div class="container">
	<div class="row">
		<div class="col-lg-6 col-xlg-9 col-md-7 col-md-offset-2">
                        <div class="card">
                            <div class="card-block">
                                 <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#home">List Of Business</a></li>
                                    
                                  </ul>
                                  <div class="tab-content">
                                    <div id="home" class="tab-pane fade in active">
                                      <div class="col-sm-9">
                                      <form action="business_list.php" id="bus_list" method="POST">
                                      <input type="text" name="valueToSearch" class="form-control" placeholder="Value To Search">
                                      <input type="submit" name="submit" class="btn btn-info" value="Filter">
                                        <table class="table table-condensed table-bordered" id="myTable">
                                        <thead>
                                          <tr>
                                            <th><a href="#" class="column_sort" id = "name" data-order="desc">Name </a></th>
                                            <th><a href="#" class="column_sort" id = "bus_name" data-order="desc">Business Name</a></th>
                                            <th><a href="#" class="column_sort" id = "bus_cat" data-order="desc">Business Category</a></th>
                                            <th><a href="#" class="column_sort" id = "email" data-order="desc">Email</a></th>
                                            <th><a href="#" class="column_sort" id = "mobile" data-order="desc">Mobile</a></th>
                                            <th>Operation</th>
                                            <th>Operation</th>
                                          </tr>
                                        </thead>
                                        <tbody><?php 
                                        while($row = mysqli_fetch_assoc($search_result)){
                                             ?><tr>
                                            <td><?php echo $row['name']; ?></td>
                                            <td><?php echo $row['bus_name']; ?></td>
                                            <td><?php echo $row['bus_cat']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['mobile']; ?></td>
                                            <td><a href="approve_user.php?id=<?php echo $row['id']; ?>"><?php echo $row['status']; ?></a></td>
                                            <td><a href="delete_business.php?id=<?php echo $row['id']; ?>">DELETE</a></td>
                                          </tr>
                                          <?php 
                                        }
                                        ?>
                                         
                                        </tbody>
                                      </table>
                                      </form>
                                    </div>
                                    <div class="col-sm-3">
                                      <!-- <select class="form-control" onchange="myFunction()" id="mylist" name="category">
                                        <option disabled selected>Order By</option>
                                        <option>a</option>
                                        <option>b</option>

                                      </select>  -->
                                      </div>                                   
                                    </div>
                                  </div>
                            </div>
                        </div>
                    </div>
	</div>
</div>
</section>
<script>
  /*function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("mylist");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}*/

$(document).ready(function(){
  $(document).on('click', '.column_sort', function(){
    var column_name = $(this).attr("id");
    var order = $(this).data("order");
    //alert(order);
    var arrow = '';
    if(order == 'asc'){
      arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-up"></span>';
    }else{
      arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-down"></span>';
    }
    /*if(order == 'desc'){
      arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-down"></span>';
    }else{
      arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-up"></span>';
    }*/
    //alert(column_name);
    $.ajax({
      url : 'modules/sort.php',
      method : "POST",
      data : {column_name:column_name, order:order},
      success:function(data)
      {
        //alert(data);
        $('#myTable').html(data);
        $('#'+column_name+'').append(arrow);
      }
    });
  });
});
</script>


<!-- <script>
$(document).ready(function(){
  $(".column_sort").click(function(){
    alert("The paragraph was clicked.");
  });
});
</script> -->

<?php include('footer.php'); ?>