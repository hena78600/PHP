<?php include('header.php'); ?>
<?php include('sidebar.php');
if(!isset($_SESSION['admin'])){
    header('location:index.php');
}
$con = connect_db();
$sql = mysqli_query($con, "SELECT * FROM business_category");
?>
<section class="sec-profile-admn">
<div class="container">
    <div class="row">
        <div class="col-lg-6 col-xlg-9 col-md-7 col-md-offset-2">
                        <div class="card">
                            <div class="card-block">
                                 <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#home">Add Category</a></li>
                                    <li><a data-toggle="tab" href="#menu1">Edit/Delete Category </a></li>
                                    
                                  </ul>
                                  <div class="tab-content">
                                    <div id="home" class="tab-pane fade in active">
                                    <form id="Bus_Form" method="POST">
                                        <div class="form-group">
                                            <label class="col-md-12">Business Category</label>
                                            <div class="col-md-12">
                                                <input type="text" id="inputName" placeholder="Category Name" class="form-control form-control-line">
                                            </div>
                                        </div>
                                    
                                        <div class="form-group">
                                            <div class="col-sm-12">                                            
                                                <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Add">
                                            </div>
                                        </div>
                                    </form>
                                    </div>
                                    <div id="menu1" class="tab-pane fade in">
                                        <table class="table table-condensed" >
                                        <thead>
                                          <tr>
                                            <th>Category Name</th>
                                            <th>Operation</th>
                                            <th>Operation</th>
                                            
                                          </tr>
                                        </thead>
                                        <tbody><?php 
                                        while($row = mysqli_fetch_assoc($sql)){
                                             ?><tr>
                                            <td><?php echo $row['cat_name']; ?></td>
                                            
                                            <td><a href="edit_cat.php?user_id=<?php echo $row['id']; ?>">Edit</a></td>
                                            <td><a href="delete_cat.php?id=<?php echo $row['id']; ?>">Delete</a></td>
                                          </tr>
                                          <?php 
                                        }
                                        ?>
                                         
                                         
                                        </tbody>
                                      </table>
                                    </div>
                                   
                                  </div>

                            </div>
                        </div>
                    </div>
    </div>
</div>
</section>


<script>
    $('#Bus_Form').submit(function(any){
        any.preventDefault();
        var name = $('#inputName').val();
        if(name == ''){
            alert('Please Enter Category');
        }
        else {
            var dataString = "cat_name="+name;
            $.ajax({
            type: "POST",
            url: "modules/admin_cat.php",
            data: dataString,
            cache: false,
            success: function(result){
               alert(result);
            }
        });
        }

        
    });
        /*alert('hi');*/
    

</script>



<?php include('footer.php'); ?>