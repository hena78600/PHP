<?php include 'function.php';
$con = connect_db();
if(isset($_GET['id'])){
	$id = $_GET['id'];
	$check = mysqli_query($con, "SELECT * FROM users WHERE id='$id'");
	$row = mysqli_fetch_assoc($check);
	$status = $row['status'];
	if($status === 'PENDING'){
		$sql = mysqli_query($con, "UPDATE users SET status='APPROVED' WHERE id='$id'");
		echo "<script>alert('User Approved');</script>";
		echo "<script>window.location.href='business_list.php'</script>";
	}else{
		$sql = mysqli_query($con, "UPDATE users SET status='PENDING' WHERE id='$id'");
		echo "<script>alert('User is in Pending');</script>";
		echo "<script>window.location.href='business_list.php'</script>";
	}
} 
 ?>

