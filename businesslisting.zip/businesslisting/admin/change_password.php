<?php include('header.php'); ?>
<?php include('sidebar.php');
if(!isset($_SESSION['admin'])){
    header('location:index.php');
}
?>

<section class="sec-profile-admn">
<div class="container">
	<div class="row">
		<div class="col-lg-6 col-xlg-9 col-md-7 col-md-offset-2">
			<h2>Change Password</h2><br>
         <form role="form" class="form-horizontal" method="POST" id="Login_Form" onsubmit=" return validate();">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="recent_pass" control-label">
                                            Current Password</label>
                                        </div>
                                        <div class="col-sm-12">
                                            <input type="password" class="form-control" id="recent_pass" />
                                            <p id="valid_rec_pass"></p>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="new_pass" control-label">
                                            New Password</label>
                                        </div>
                                        <div class="col-sm-12">
                                            <input type="password" class="form-control" id="new_pass" />
                                            <p id="valid_new_pass"></p>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="con_pass" control-label">
                                            Confirm Password</label>
                                        </div>
                                        <div class="col-sm-12">
                                            <input type="password" class="form-control" id="con_pass" />
                                            <p id="valid_con_pass"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                        </div>
                                        <div class="col-sm-12">                                            
                                                <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Submit">
                                                <span id="Result"></span>
                                        </div>
                                    </div>
                                </form>

		</div>
	</div>
</div>
</section>
<script>
    function validate(){
        var flag = true;
        var rec_pass = $('#recent_pass').val().trim();
        if(rec_pass == ''){
            flag = false;
            $('#valid_rec_pass').html('<h6 class="text-danger pull-right">*Enter Recent Password</h6>');
        }else{
            $('#valid_rec_pass').html("");
        }
        var new_pass = $('#new_pass').val().trim();
        if(new_pass == ''){
            flag = false;
            $('#valid_new_pass').html('<h6 class="text-danger pull-right">*Enter New Password</h6>');
        }else{
            $('#valid_new_pass').html("");
        }
        var con_pass = $('#con_pass').val().trim();
        if(con_pass == ''){
            flag = false;
            $('#valid_con_pass').html('<h6 class="text-danger pull-right">*Enter Confirm Password</h6>');
        }else{
            $('#valid_con_pass').html("");
        }
            if(new_pass != '' && con_pass == '' && con_pass == new_pass){
                flag = false;
                $('#valid_con_pass').html('<h6 class="text-info pull-right">Password matched</h6>');
            }else if(new_pass != '' && con_pass == '') {
                flag = false;
                $('#valid_con_pass').html('<h6 class="text-danger pull-right">*Password not matched</h6>');
            }
        if(rec_pass != '' && new_pass != '' && con_pass != ''){
        var dataString = "rec_pass="+rec_pass+"&new_pass="+new_pass+"&con_pass="+con_pass;
        //alert(dataString);
        $.ajax({
                type: "POST",
                url: "modules/chng_pass.php",
                data: dataString,
                cache: false,
                success: function(result){
                   alert(result);
                }
            });
        }


    return flag;

    }
</script>






<?php include('footer.php'); ?>