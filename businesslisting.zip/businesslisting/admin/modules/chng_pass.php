<?php include '../function.php';
$con = connect_db();

if(isset($_POST['rec_pass'], $_POST['con_pass'])){
	$email = $_SESSION['admin'];
	//echo $email; exit;
	$rec_pass = $_POST['rec_pass'];
	$new_pass = $_POST['new_pass'];
	$con_pass = $_POST['con_pass'];
	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";*/
	//echo $con_pass; exit;
	$sql = mysqli_query($con, "SELECT * FROM admin WHERE email = '$email'");
	$row = mysqli_fetch_assoc($sql);
	$pass = $row['password'];
	if($new_pass != $con_pass){
		echo "Password Mismatched";
	}else if($rec_pass === $pass ){
		$change = mysqli_query($con, "UPDATE admin SET password = '$con_pass' WHERE email = '$email'");
		echo "Password changed Successfully";
	}else{
		echo "Invalid Current Password";
	}
}

?>
