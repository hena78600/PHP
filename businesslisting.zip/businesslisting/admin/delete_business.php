<?php
include('function.php');
$con = connect_db();
$id = $_GET['id'];
$sql = mysqli_query($con, "DELETE FROM users WHERE id = '$id'");
echo "<script>alert('user deleted successfully');</script>";
echo "<script>window.location.href='business_list.php'</script>"

?>