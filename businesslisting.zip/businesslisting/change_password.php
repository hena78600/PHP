<?php
include 'function.php';
if(!isset($_SESSION['users']))  
            {    
                header("Location: index.php");
            } 
 include ('header.php');
 include ('sidebar.php'); 
?>

<section class="user_profile_sec">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-1">
				<h2>Change Password</h2>
                <form role="form" class="form-horizontal" method="POST" id="Login_Form" onsubmit=" return validate();">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="recent_pass" control-label">
                                            Current Password</label>
                                        </div>
                                        <div class="col-sm-12">
                                            <input type="password" class="form-control" id="recent_pass" />
                                            <p id="valid_rec_pass"></p>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="new_pass" control-label">
                                            New Password</label>
                                        </div>
                                        <div class="col-sm-12">
                                            <input type="password" class="form-control" id="new_pass" />
                                            <p id="valid_new_pass"></p>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="con_pass" control-label">
                                            Confirm Password</label>
                                        </div>
                                        <div class="col-sm-12">
                                            <input type="password" class="form-control" id="con_pass" />
                                            <p id="valid_con_pass"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                        </div>
                                        <div class="col-sm-12">                                            
                                                <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Submit">
                                        </div>
                                        <div class="col-sm-12">
                                            <div id="ChngePASsword"></div>
                                        </div>
                                    </div>
                                </form>
				
			</div>
		</div>
</section>
<script>
    function validate(){
        var flag = true;
        var rec_pass = $('#recent_pass').val().trim();
        if(rec_pass == ''){
            flag = false;
            $('#valid_rec_pass').html('<h6 class="text-danger pull-right">*Enter Current Password</h6>');
        }else{
            $('#valid_rec_pass').html("");
        }
        var new_pass = $('#new_pass').val().trim();
        flag = false;
        if(new_pass == ''){
            flag = false;
            $('#valid_new_pass').html('<h6 class="text-danger pull-right">*Enter New Password</h6>');
        }else{
            $('#valid_new_pass').html("");
        }
        var con_pass = $('#con_pass').val().trim();
        if(con_pass == ''){
            flag = false;
            $('#valid_con_pass').html('<h6 class="text-danger pull-right">*Confirm Password</h6>');
        }else{
            $('#valid_con_pass').html("");
        }
        if(con_pass == new_pass && (new_pass != '' && con_pass != '')){
                flag = false;
                $('#valid_con_pass').html('<h6 class="text-danger pull-right">*Password matched</h6>');
            }else if((new_pass != '' && con_pass != '')){
                flag = false;
                $('#valid_con_pass').html('<h6 class="text-danger pull-right">*Password not matched</h6>');
            }
        
        if(rec_pass != '' && new_pass != '' && con_pass != ''){
        var dataString = "rec_pass="+rec_pass+"&new_pass="+new_pass+"&con_pass="+con_pass;
        //alert(dataString);
        $.ajax({
                type: "POST",
                url: "modules/chng_pass.php",
                data: dataString,
                cache: false,
                success: function(result){
                    alert(result);
                    /*if(result == 'success'){
                        $('#ChngePASsword').html("<p>Password Changed Successfully</p>");
                    }*/
                }
            });
        }


    return flag;

    }
   
</script>


 <?php include 'footer.php'; ?> 