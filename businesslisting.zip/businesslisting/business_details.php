<?php include ('function.php');
 include ('header.php'); 
 $id = $_GET['id'];
 $sql = mysqli_query($con, "SELECT * FROM users WHERE id = '$id'");
 $row = mysqli_fetch_assoc($sql);
 ?>
<section class="details-sec">
		 <div class="container">
        	<div class="row">
               <div class="col-xs-4 item-photo">
                    <img style="max-width:100%;" src="<?php echo 'uploads/'.$row['logo']; ?>" />
                </div>
                <div class="col-xs-5" style="border:0px solid gray">
                    <!-- Datos del vendedor y titulo del producto -->
                    <h3><?php echo $row['bus_name']; ?></h3>    
                    <h5 style="color:#337ab7"> <?php echo $row['bus_cat']; ?></h5>
        
                    <!-- Precios -->
                    <h5 class="title-price"><?php echo $row['address']; ?></h5>
                    <h3 style="margin-top:0px;"><?php echo $row['description']; ?></h3>
        
                    <!-- Detalles especificos del producto -->
                    <!-- <div class="section">
                        <h6 class="title-attr" style="margin-top:15px;" ><small>COLOR</small></h6>                    
                        <div>
                            <div class="attr" style="width:25px;background:#5a5a5a;"></div>
                            <div class="attr" style="width:25px;background:white;"></div>
                        </div>
                    </div>
                    <div class="section" style="padding-bottom:5px;">
                        <h6 class="title-attr"><small>CAPACIDAD</small></h6>                    
                        <div>
                            <div class="attr2">16 GB</div>
                            <div class="attr2">32 GB</div>
                        </div>
                    </div>   
                    <div class="section" style="padding-bottom:20px;">
                        <h6 class="title-attr"><small>CANTIDAD</small></h6>                    
                        <div>
                            <div class="btn-minus"><span class="glyphicon glyphicon-minus"></span></div>
                            <input value="1" />
                            <div class="btn-plus"><span class="glyphicon glyphicon-plus"></span></div>
                        </div>
                    </div>  -->               
        
                    <!-- Botones de compra -->
                    <div class="section" style="padding-bottom:20px;">
                        <?php
                        if(isset($_SESSION['users'])){
                        $email = $_SESSION['users'];
                        $check = mysqli_query($con, "SELECT * FROM bus_like WHERE bus_id = '$id' AND user_email = '$email'");
                        if(mysqli_num_rows($check) > 0){
                            ?>
                            <button class="like btn btn-success" id="<?php echo $row['id']; ?>"><span style="margin-right:20px" class="glyphicon glyphicon-thumbs-down" aria-hidden="true"></span> Dislike</button>
                        <?php }else{
                           ?> <button class="like btn btn-success" id="<?php echo $row['id']; ?>"><span style="margin-right:20px" class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span> Like</button>
                        <?php }
                    }else{
                        echo "First login to like";
                    }
                        ?>
                        <!-- <button class="like btn btn-success"><span style="margin-right:20px" class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span> Like</button> -->
                        <?php if(isset($_SESSION['users'])){
                            $email = $_SESSION['users'];
                            $query = mysqli_query($con, "SELECT * FROM user_fav WHERE bus_id = '$id' AND user_email = '$email'");
                            if(mysqli_num_rows($query) > 0){
                            ?>
                            <h2><button class="fav btn btn-danger" b_id="<?php echo $row['id']; ?>"><span class="glyphicon glyphicon-heart" style="cursor:pointer;"></span></button></h2>
                    <?php } else{
                        ?>  <h2><button class="fav btn btn-danger" b_id="<?php echo $row['id']; ?>"><span class="     glyphicon glyphicon-heart-empty" style="cursor:pointer;"></span></button></h2>
                    
                    <?php } } ?>
                    </div>                                        
                </div>
            </div>
        </div>
    </section>
<script>
    $(document).ready(function(){
        $('.like').click(function(){
            var id = $(this).attr('id');
            $.ajax({
                url : 'modules/likes.php',
                type : 'post',
                async: false,
                data:{
                    'id' : id,
                },
                success:function(result){
                    /*alert(result);*/
                    if(result == 'success'){
                    
                    window.location.reload();
                }
                }
            });
        });
    });
    $(document).ready(function(){
        $('.fav').click(function(){
            //alert('id');
            var b_id = $(this).attr('b_id');

            $.ajax({
                type : 'POST',
                url : 'modules/fav.php',
                data : {
                    'b_id' : b_id,
                },
                success : function(result){
                    if(result == 'success'){
                        window.location.reload();
                    }else{
                    window.location.reload();
                }
                }
            });
        });
    });
</script>


<!--  <?php //include('footer.php'); ?> -->