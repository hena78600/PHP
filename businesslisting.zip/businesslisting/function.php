<?php
session_start();
/*Connecting to Database*/
function connect_db(){
	$con = mysqli_connect('localhost', 'root', '123', 'businesslisting'); 
	if($con){
		return $con;
	}else{
		die('Database connectivity Error');
	}
}
$con = connect_db();
?>